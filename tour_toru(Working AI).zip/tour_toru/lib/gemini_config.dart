// Paste your Google AI Studio API key between the quotes.
const geminiApiKey = 'AQ.Ab8RN6IESKTkfVx6sWxwacGjrJzVPeNSijTtiAJvpCzTiBya8A';
