import 'package:flutter/material.dart';
import 'home_page.dart';
import 'forum_page.dart';
import 'map_page.dart';
import 'ai_assistant_page.dart';
import 'store_page.dart';

void main() {
  runApp(const TorunApp());
}

class TorunApp extends StatelessWidget {
  const TorunApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tour Toruń',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: kBgBlue,
        colorScheme: ColorScheme.fromSeed(seedColor: kNavy),
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int currentTab = 0;
  int coins = 120;
  int completedQuestsBase = 2;
  bool showQuestMapOnHome = false;

  // shortcut: in-memory state only, add SharedPreferences/backend when persistence is needed
  final List<QuestItem> quests = [
    QuestItem(title: 'Visit Old Town', icon: Icons.location_on_outlined, badge: '70%', reward: 40),
    QuestItem(title: 'Find 3 Landmarks', icon: Icons.camera_alt_outlined, badge: '2/3', reward: 50),
    QuestItem(title: 'Take a River Walk', icon: Icons.route_outlined, badge: '45%', reward: 35),
    QuestItem(title: 'Collect 5 Photos', icon: Icons.photo_camera_outlined, badge: '4/5', reward: 45),
    QuestItem(title: 'Complete the Loop', icon: Icons.check_circle_outline, badge: 'Go', reward: 60),
  ];

  final List<StoreItem> storeItems = [
    StoreItem(
      id: 'shades',
      name: 'Cool Sunglasses',
      slot: 'eyes',
      price: 0,
      icon: Icons.wb_sunny_outlined,
      color: Colors.orangeAccent,
      owned: true,
      equipped: true,
    ),
    StoreItem(
      id: 'hat',
      name: 'Copernicus Astro Hat',
      slot: 'head',
      price: 50,
      icon: Icons.auto_awesome,
      color: Colors.indigo,
    ),
    StoreItem(
      id: 'crown',
      name: 'Gothic Gold Crown',
      slot: 'head',
      price: 80,
      icon: Icons.emoji_events,
      color: Colors.amber,
    ),
    StoreItem(
      id: 'gingerbread',
      name: 'Toruń Gingerbread Charm',
      slot: 'badge',
      price: 40,
      icon: Icons.cookie_outlined,
      color: Colors.brown,
    ),
    StoreItem(
      id: 'scarf',
      name: 'Vistula Traveler Scarf',
      slot: 'neck',
      price: 45,
      icon: Icons.dry_cleaning_outlined,
      color: Colors.redAccent,
    ),
    StoreItem(
      id: 'shield',
      name: 'Teutonic Mini Shield',
      slot: 'badge',
      price: 60,
      icon: Icons.shield_outlined,
      color: Colors.blueGrey,
    ),
  ];

  void completeQuest(QuestItem q) {
    if (q.completed) return;
    setState(() {
      q.completed = true;
      q.badge = 'Done';
      coins += q.reward;
      completedQuestsBase += 1;
    });
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Quest "${q.title}" completed! +${q.reward} coins'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void buyOrToggleItem(StoreItem item) {
    if (!item.owned) {
      if (coins < item.price) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Not enough coins! Complete quests on Home first.')),
        );
        return;
      }
      setState(() {
        coins -= item.price;
        item.owned = true;
        for (final other in storeItems.where((e) => e.slot == item.slot)) {
          other.equipped = false;
        }
        item.equipped = true;
      });
    } else {
      setState(() {
        final next = !item.equipped;
        for (final other in storeItems.where((e) => e.slot == item.slot)) {
          other.equipped = false;
        }
        item.equipped = next;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
        quests: quests,
        storeItems: storeItems,
        coins: coins,
        completedQuestsBase: completedQuestsBase,
        showQuestMapOnHome: showQuestMapOnHome,
        onToggleQuestMap: (val) => setState(() => showQuestMapOnHome = val),
        onCompleteQuest: completeQuest,
        onOpenFullMap: () => setState(() => currentTab = 2),
      ),
      const ForumPage(),
      const TorunMapPage(),
      const AiAssistantPage(),
      StorePage(
        coins: coins,
        storeItems: storeItems,
        onBuyOrToggle: buyOrToggleItem,
      ),
    ];

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(child: pages[currentTab]),
            _buildBottomNav(),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    const labels = ['Home', 'Forum', 'Map', 'AI', 'Store'];
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
      child: Container(
        height: 70,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        decoration: BoxDecoration(
          color: kNavy,
          borderRadius: BorderRadius.circular(36),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(labels.length, (i) {
            final selected = currentTab == i;
            return Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => setState(() => currentTab = i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 160),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: selected ? Colors.white : kNavyLight,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text(
                      labels[i],
                      style: TextStyle(
                        color: selected ? kNavy : Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}