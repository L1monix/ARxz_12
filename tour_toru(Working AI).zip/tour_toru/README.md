# tour_toru

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Learn Flutter](https://docs.flutter.dev/get-started/learn-flutter)
- [Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Flutter learning resources](https://docs.flutter.dev/reference/learning-resources)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

## Gemini AI assistant

Add your Google AI Studio API key to `lib/gemini_config.dart`:

```dart
const geminiApiKey = 'AQ.Ab8RN6IESKTkfVx6sWxwacGjrJzVPeNSijTtiAJvpCzTiBya8A';
```

If the file is missing, copy `lib/gemini_config.example.dart` to
`lib/gemini_config.dart`. The local config file is ignored by Git. Start the
app normally with `flutter run -d chrome`; no `--dart-define` is needed.

Keys included in a Flutter Web or mobile app can be recovered from the app.
Use a backend proxy to protect the key before publishing the app. If a key has
been shared or exposed, revoke it and create a replacement in Google AI Studio.
