import 'package:flutter/material.dart';
import 'home_page.dart';

class AiAssistantPage extends StatefulWidget {
  const AiAssistantPage({super.key});

  @override
  State<AiAssistantPage> createState() => _AiAssistantPageState();
}

class _AiAssistantPageState extends State<AiAssistantPage> {
  final TextEditingController _inputCtrl = TextEditingController();
  String selectedTopic = 'Old Town Gothic';
  final List<Map<String, String>> messages = [
    {
      'sender': 'ai',
      'text':
          'Welcome to Toruń (Kuyavian-Pomeranian Voivodeship, Poland)! Ask me about Gothic landmarks, Nicolaus Copernicus, gingerbread workshops, or scenic routes.',
    },
  ];

  final Map<String, String> topicGuides = {
    'Old Town Gothic':
        'Toruń’s Medieval Town is a UNESCO World Heritage site! Start at the Old Town Hall (Ratusz), visit the Cathedral of SS. John the Baptist and John the Evangelist, and see the Leaning Tower (Krzywa Wieża).',
    'Copernicus Trail':
        'Nicolaus Copernicus was born in Toruń in 1473! Visit the House of Nicolaus Copernicus Museum on Kopernika 15/17, take a photo at his monument on the Market Square, and watch a show at the Planetarium.',
    'Gingerbread & Food':
        'Toruń is the capital of Polish gingerbread (Pierniki). Visit the Living Museum of Gingerbread to bake your own Katarzynki, and try pierogi in the Old Town.',
    'Vistula & Ruins':
        'Walk along Bulwar Filadelfijski by the Vistula River, explore the 13th-century Teutonic Castle ruins, and cross to the Kępa Bazarowa viewpoint at sunset for the best skyline photo!',
  };

  void _sendMessage([String? preset]) {
    final text = (preset ?? _inputCtrl.text).trim();
    if (text.isEmpty) return;
    setState(() {
      messages.add({'sender': 'user', 'text': text});
      _inputCtrl.clear();
      messages.add({
        'sender': 'ai',
        'text': _replyForQuery(text),
      });
    });
  }

  String _replyForQuery(String q) {
    final lower = q.toLowerCase();
    if (lower.contains('copernicus') || lower.contains('planetarium') || lower.contains('astro')) {
      return topicGuides['Copernicus Trail']!;
    }
    if (lower.contains('gingerbread') || lower.contains('food') || lower.contains('eat') || lower.contains('piernik')) {
      return topicGuides['Gingerbread & Food']!;
    }
    if (lower.contains('castle') || lower.contains('river') || lower.contains('vistula') || lower.contains('view')) {
      return topicGuides['Vistula & Ruins']!;
    }
    return 'For your visit to Toruń (Kuyavian-Pomeranian, Poland): check out the Old Town Market Square, the Leaning Tower (Krzywa Wieża), the House of Copernicus, and the Teutonic Castle ruins!';
  }

  @override
  Widget build(BuildContext context) {
    final topics = topicGuides.keys.toList();
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
      child: Container(
        decoration: BoxDecoration(
          color: kCardWhite,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kNavy.withValues(alpha: 0.25), width: 1.5),
        ),
        child: Row(
          children: [
            Container(
              width: 132,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: kSoftBlue,
                borderRadius: const BorderRadius.horizontal(left: Radius.circular(18)),
                border: Border(
                  right: BorderSide(color: kNavy.withValues(alpha: 0.2), width: 1.5),
                ),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      InkWell(
                        onTap: () {
                          setState(() {
                            messages
                              ..clear()
                              ..add({
                                'sender': 'ai',
                                'text': 'Chat reset! Pick a Toruń filter or ask any question.',
                              });
                          });
                        },
                        child: Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: kCardWhite,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: kNavy.withValues(alpha: 0.3)),
                          ),
                          child: const Icon(Icons.tune, size: 16, color: kNavy),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Container(
                          height: 32,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: kCardWhite,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: kNavy.withValues(alpha: 0.3)),
                          ),
                          child: const Text(
                            'Filter',
                            style: TextStyle(
                              color: kNavy,
                              fontWeight: FontWeight.w800,
                              fontSize: 11,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  ...topics.map((topic) {
                    final active = selectedTopic == topic;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(10),
                        onTap: () {
                          setState(() => selectedTopic = topic);
                          _sendMessage('Tell me about $topic in Toruń');
                        },
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                          decoration: BoxDecoration(
                            color: active ? kNavy : kCardWhite,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: kNavy.withValues(alpha: 0.3)),
                          ),
                          child: Text(
                            topic,
                            style: TextStyle(
                              color: active ? Colors.white : kNavy,
                              fontWeight: FontWeight.w700,
                              fontSize: 10.5,
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: kSoftBlue,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Text(
                        'Toruń AI Tourist Assistant (Kuyavian-Pomeranian)',
                        style: TextStyle(
                          color: kNavy,
                          fontWeight: FontWeight.w800,
                          fontSize: 11.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Expanded(
                      child: ListView.builder(
                        itemCount: messages.length,
                        itemBuilder: (context, index) {
                          final msg = messages[index];
                          final isUser = msg['sender'] == 'user';
                          return Align(
                            alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                            child: Container(
                              margin: const EdgeInsets.symmetric(vertical: 4),
                              padding: const EdgeInsets.all(10),
                              constraints: const BoxConstraints(maxWidth: 230),
                              decoration: BoxDecoration(
                                color: isUser ? kNavy : kSoftBlue,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                msg['text']!,
                                style: TextStyle(
                                  color: isUser ? Colors.white : kNavy,
                                  fontSize: 12,
                                  height: 1.35,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            height: 42,
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            decoration: BoxDecoration(
                              color: kSoftBlue,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: kNavy.withValues(alpha: 0.35)),
                            ),
                            alignment: Alignment.center,
                            child: TextField(
                              controller: _inputCtrl,
                              decoration: const InputDecoration(
                                hintText: 'Ask about Toruń sights...',
                                border: InputBorder.none,
                                isDense: true,
                              ),
                              style: const TextStyle(fontSize: 12, color: kNavy),
                              onSubmitted: (_) => _sendMessage(),
                            ),
                          ),
                        ),
                        const SizedBox(width: 6),
                        InkWell(
                          onTap: _sendMessage,
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            width: 40,
                            height: 42,
                            decoration: BoxDecoration(
                              color: kNavy,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}