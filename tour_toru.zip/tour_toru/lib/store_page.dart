import 'package:flutter/material.dart';
import 'home_page.dart';

class StorePage extends StatelessWidget {
  final int coins;
  final List<StoreItem> storeItems;
  final ValueChanged<StoreItem> onBuyOrToggle;

  const StorePage({
    super.key,
    required this.coins,
    required this.storeItems,
    required this.onBuyOrToggle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: kCardWhite,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                AvatarWidget(storeItems: storeItems, size: 76),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Avatar Accessory Store',
                        style: TextStyle(
                          color: kNavy,
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Complete quests on Home to earn coins and customize your guide avatar!',
                        style: TextStyle(color: kTextMuted, fontSize: 12),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: kSoftBlue,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          'Balance: $coins coins',
                          style: const TextStyle(
                            color: kNavy,
                            fontWeight: FontWeight.w800,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: GridView.builder(
              itemCount: storeItems.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.15,
              ),
              itemBuilder: (context, index) {
                final item = storeItems[index];
                return Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: kCardWhite,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: item.equipped ? kNavy : Colors.transparent,
                      width: 2,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CircleAvatar(
                        radius: 22,
                        backgroundColor: kSoftBlue,
                        child: Icon(item.icon, color: item.color, size: 26),
                      ),
                      Text(
                        item.name,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: kNavy,
                          fontWeight: FontWeight.w700,
                          fontSize: 12.5,
                        ),
                      ),
                      SizedBox(
                        width: double.infinity,
                        height: 32,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: item.equipped
                                ? kNavy
                                : item.owned
                                    ? kSoftBlue
                                    : const Color(0xFF2E6B9E),
                            foregroundColor: item.equipped
                                ? Colors.white
                                : item.owned
                                    ? kNavy
                                    : Colors.white,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          onPressed: () => onBuyOrToggle(item),
                          child: Text(
                            item.equipped
                                ? 'Equipped'
                                : item.owned
                                    ? 'Equip'
                                    : 'Buy (${item.price} coins)',
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}