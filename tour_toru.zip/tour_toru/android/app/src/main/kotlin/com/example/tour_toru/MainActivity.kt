package com.example.tour_toru

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
