import 'package:flutter/material.dart';
import 'home_page.dart';

class ThreadPost {
  final String author;
  final String handle;
  final String time;
  final String content;
  int likes;
  int replies;
  int shares;
  bool liked;

  ThreadPost({
    required this.author,
    required this.handle,
    required this.time,
    required this.content,
    this.likes = 0,
    this.replies = 0,
    this.shares = 0,
    this.liked = false,
  });
}

class ForumPage extends StatefulWidget {
  const ForumPage({super.key});

  @override
  State<ForumPage> createState() => _ForumPageState();
}

class _ForumPageState extends State<ForumPage> {
  final TextEditingController _postCtrl = TextEditingController();
  final List<ThreadPost> _posts = [
    ThreadPost(
      author: 'Anna Kowalska',
      handle: '@anna_torun',
      time: '12m',
      content:
          'Just climbed the Old Town Hall tower in Toruń! The panoramic view over the Vistula River and Gothic rooftops is unforgettable.',
      likes: 28,
      replies: 6,
      shares: 4,
    ),
    ThreadPost(
      author: 'Lucas Traveler',
      handle: '@lucas_pl',
      time: '1h',
      content:
          'Pro tip for tourists: book the Living Museum of Gingerbread (Żywe Muzeum Piernika) workshop early in the morning. You bake your own traditional Katarzynki!',
      likes: 45,
      replies: 11,
      shares: 9,
    ),
    ThreadPost(
      author: 'Marta Nowak',
      handle: '@marta_guides',
      time: '3h',
      content:
          'Evening walk from the Leaning Tower (Krzywa Wieża) to the Teutonic Castle ruins. Completed 2 quests and unlocked a new badge!',
      likes: 19,
      replies: 3,
      shares: 2,
    ),
  ];

  void _addPost() {
    final text = _postCtrl.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _posts.insert(
        0,
        ThreadPost(
          author: 'Traveler Guide',
          handle: '@you',
          time: 'now',
          content: text,
        ),
      );
      _postCtrl.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: kCardWhite,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 18,
                  backgroundColor: kSoftBlue,
                  child: Icon(Icons.forum_outlined, color: kNavy, size: 18),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _postCtrl,
                    decoration: const InputDecoration(
                      hintText: 'Start a thread about Toruń...',
                      border: InputBorder.none,
                      isDense: true,
                    ),
                    onSubmitted: (_) => _addPost(),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kNavy,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: _addPost,
                  child: const Text('Post'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: ListView.separated(
              itemCount: _posts.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final post = _posts[index];
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      children: [
                        CircleAvatar(
                          radius: 24,
                          backgroundColor: kCardWhite,
                          child: Text(
                            post.author[0],
                            style: const TextStyle(
                              color: kNavy,
                              fontWeight: FontWeight.w800,
                              fontSize: 18,
                            ),
                          ),
                        ),
                        Container(
                          width: 2,
                          height: 55,
                          margin: const EdgeInsets.only(top: 6),
                          color: kNavy.withValues(alpha: 0.2),
                        ),
                      ],
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: kCardWhite,
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(color: kNavy.withValues(alpha: 0.15)),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      '${post.author}  ${post.handle}',
                                      style: const TextStyle(
                                        color: kNavy,
                                        fontWeight: FontWeight.w800,
                                        fontSize: 13,
                                      ),
                                    ),
                                    Text(
                                      post.time,
                                      style: const TextStyle(color: kTextMuted, fontSize: 11),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  post.content,
                                  style: const TextStyle(
                                    color: kNavy,
                                    fontSize: 13,
                                    height: 1.35,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _ThreadActionSquare(
                                icon: post.liked ? Icons.favorite : Icons.favorite_border,
                                count: post.likes,
                                active: post.liked,
                                onTap: () {
                                  setState(() {
                                    post.liked = !post.liked;
                                    post.likes += post.liked ? 1 : -1;
                                  });
                                },
                              ),
                              const SizedBox(width: 8),
                              _ThreadActionSquare(
                                icon: Icons.chat_bubble_outline,
                                count: post.replies,
                                onTap: () {
                                  setState(() => post.replies += 1);
                                },
                              ),
                              const SizedBox(width: 8),
                              _ThreadActionSquare(
                                icon: Icons.repeat,
                                count: post.shares,
                                onTap: () {
                                  setState(() => post.shares += 1);
                                },
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ThreadActionSquare extends StatelessWidget {
  final IconData icon;
  final int count;
  final bool active;
  final VoidCallback onTap;

  const _ThreadActionSquare({
    required this.icon,
    required this.count,
    this.active = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: kCardWhite,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: kNavy.withValues(alpha: 0.25)),
        ),
        child: Row(
          children: [
            Icon(icon, size: 15, color: active ? Colors.redAccent : kNavy),
            const SizedBox(width: 4),
            Text(
              '$count',
              style: const TextStyle(
                color: kNavy,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}