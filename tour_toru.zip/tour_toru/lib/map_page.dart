import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'home_page.dart';

class TorunMapPage extends StatefulWidget {
  const TorunMapPage({super.key});

  @override
  State<TorunMapPage> createState() => _TorunMapPageState();
}

class _TorunMapPageState extends State<TorunMapPage> {
  final LatLng torunCenter = const LatLng(53.0138, 18.5984);
  final TextEditingController _searchCtrl = TextEditingController();
  String selectedCategory = 'All';
  String sortMode = 'Popular';
  bool showSearchOverlay = false;

  final List<Map<String, dynamic>> attractions = [
    {
      'title': 'Nicolaus Copernicus Monument',
      'desc': 'Iconic 1853 bronze statue in the heart of the Old Town Market Square.',
      'category': 'Landmarks',
      'rating': 4.9,
      'popularity': 99,
      'distanceKm': 0.2,
      'point': const LatLng(53.0103, 18.6047),
      'color': Colors.redAccent,
    },
    {
      'title': 'Leaning Tower (Krzywa Wieża)',
      'desc': 'Medieval defensive tower famous for its 1.46m tilt from vertical.',
      'category': 'Landmarks',
      'rating': 4.8,
      'popularity': 95,
      'distanceKm': 0.4,
      'point': const LatLng(53.0097, 18.6022),
      'color': Colors.amber,
    },
    {
      'title': 'Teutonic Castle Ruins',
      'desc': '13th-century castle ruins overlooking the Vistula riverbank.',
      'category': 'Castles',
      'rating': 4.7,
      'popularity': 90,
      'distanceKm': 0.5,
      'point': const LatLng(53.0094, 18.6094),
      'color': Colors.deepPurpleAccent,
    },
    {
      'title': 'Living Museum of Gingerbread',
      'desc': 'Interactive museum where visitors bake traditional Toruń pierniki.',
      'category': 'Museums',
      'rating': 4.9,
      'popularity': 97,
      'distanceKm': 0.3,
      'point': const LatLng(53.0111, 18.6033),
      'color': Colors.brown,
    },
    {
      'title': 'Old Town Hall (Ratusz Staromiejski)',
      'desc': 'Brick Gothic masterpiece with a 40m observation tower & museum.',
      'category': 'Museums',
      'rating': 4.8,
      'popularity': 94,
      'distanceKm': 0.1,
      'point': const LatLng(53.0105, 18.6041),
      'color': kNavy,
    },
  ];

  @override
  Widget build(BuildContext context) {
    const categories = ['All', 'Landmarks', 'Museums', 'Castles'];
    final query = _searchCtrl.text.trim().toLowerCase();

    final filteredAttractions = attractions.where((item) {
      final matchesCat = selectedCategory == 'All' || item['category'] == selectedCategory;
      final matchesQuery = query.isEmpty ||
          (item['title'] as String).toLowerCase().contains(query) ||
          (item['desc'] as String).toLowerCase().contains(query);
      return matchesCat && matchesQuery;
    }).toList();

    final recommended = List<Map<String, dynamic>>.from(attractions);
    if (sortMode == 'Popular') {
      recommended.sort((a, b) => (b['popularity'] as int).compareTo(a['popularity'] as int));
    } else if (sortMode == 'Top Rated') {
      recommended.sort((a, b) => (b['rating'] as double).compareTo(a['rating'] as double));
    } else {
      recommended.sort((a, b) => (a['distanceKm'] as double).compareTo(b['distanceKm'] as double));
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 46,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: kCardWhite,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: kNavy.withValues(alpha: 0.25)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.search, color: kNavy),
                      const SizedBox(width: 8),
                      Expanded(
                        child: TextField(
                          controller: _searchCtrl,
                          onTap: () => setState(() => showSearchOverlay = true),
                          onChanged: (_) => setState(() => showSearchOverlay = true),
                          decoration: const InputDecoration(
                            hintText: 'Search places in Toruń...',
                            border: InputBorder.none,
                            isDense: true,
                          ),
                        ),
                      ),
                      if (showSearchOverlay)
                        IconButton(
                          icon: const Icon(Icons.close, size: 18, color: kNavy),
                          onPressed: () {
                            _searchCtrl.clear();
                            FocusScope.of(context).unfocus();
                            setState(() => showSearchOverlay = false);
                          },
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: kCardWhite,
                  shape: BoxShape.circle,
                  border: Border.all(color: kNavy.withValues(alpha: 0.25)),
                ),
                child: const Icon(Icons.person_outline, color: kNavy),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 34,
            child: Row(
              children: categories.map((cat) {
                final active = selectedCategory == cat;
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: () => setState(() => selectedCategory = cat),
                      child: Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: active ? kNavy : kCardWhite,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: kNavy.withValues(alpha: 0.2)),
                        ),
                        child: Text(
                          cat,
                          style: TextStyle(
                            color: active ? Colors.white : kNavy,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Stack(
                children: [
                  FlutterMap(
                    options: MapOptions(
                      initialCenter: torunCenter,
                      initialZoom: 15.0,
                      maxZoom: 18.0,
                      minZoom: 10.0,
                    ),
                    children: [
                      TileLayer(
                        urlTemplate:
                            'https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}.png',
                        userAgentPackageName: 'com.example.torun_app',
                      ),
                      MarkerLayer(
                        markers: filteredAttractions.map((item) {
                          return Marker(
                            point: item['point'] as LatLng,
                            width: 44,
                            height: 44,
                            child: GestureDetector(
                              onTap: () {
                                ScaffoldMessenger.of(context).hideCurrentSnackBar();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('${item['title']} — ${item['desc']}'),
                                    duration: const Duration(seconds: 2),
                                  ),
                                );
                              },
                              child: Icon(
                                Icons.location_pin,
                                size: 42,
                                color: item['color'] as Color,
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                  if (showSearchOverlay)
                    Container(
                      color: kBgBlue.withValues(alpha: 0.96),
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: kCardWhite,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(color: kNavy.withValues(alpha: 0.2)),
                              ),
                              child: filteredAttractions.isEmpty
                                  ? const Center(child: Text('No matching places found'))
                                  : ListView.builder(
                                      itemCount: filteredAttractions.length,
                                      itemBuilder: (context, idx) {
                                        final item = filteredAttractions[idx];
                                        return ListTile(
                                          dense: true,
                                          leading: Icon(
                                            Icons.place_outlined,
                                            color: item['color'] as Color,
                                          ),
                                          title: Text(
                                            item['title'] as String,
                                            style: const TextStyle(
                                              color: kNavy,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                          subtitle: Text(
                                            '${item['category']} • ★ ${item['rating']} • ${item['distanceKm']} km',
                                            style: const TextStyle(fontSize: 11),
                                          ),
                                          onTap: () {
                                            setState(() => showSearchOverlay = false);
                                            FocusScope.of(context).unfocus();
                                          },
                                        );
                                      },
                                    ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'Recommendations',
                                style: TextStyle(
                                  color: kNavy,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14,
                                ),
                              ),
                              PopupMenuButton<String>(
                                initialValue: sortMode,
                                onSelected: (val) => setState(() => sortMode = val),
                                itemBuilder: (_) => const [
                                  PopupMenuItem(value: 'Popular', child: Text('By Popularity')),
                                  PopupMenuItem(value: 'Top Rated', child: Text('By Rating')),
                                  PopupMenuItem(value: 'Nearest', child: Text('Nearest')),
                                ],
                                child: Container(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: kCardWhite,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Row(
                                    children: [
                                      const Icon(Icons.sort, size: 16, color: kNavy),
                                      const SizedBox(width: 4),
                                      Text(
                                        sortMode,
                                        style: const TextStyle(
                                          color: kNavy,
                                          fontSize: 11.5,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          SizedBox(
                            height: 130,
                            child: Row(
                              children: recommended.take(3).map((item) {
                                return Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 4),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Container(
                                            width: double.infinity,
                                            decoration: BoxDecoration(
                                              color: kCardWhite,
                                              borderRadius: BorderRadius.circular(12),
                                              border: Border.all(
                                                color: kNavy.withValues(alpha: 0.2),
                                              ),
                                            ),
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Icon(
                                                  Icons.location_city,
                                                  color: item['color'] as Color,
                                                  size: 26,
                                                ),
                                                const SizedBox(height: 4),
                                                Text(
                                                  '★ ${item['rating']} • ${item['distanceKm']} km',
                                                  style: const TextStyle(
                                                    fontSize: 10,
                                                    color: kTextMuted,
                                                    fontWeight: FontWeight.w700,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          item['title'] as String,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            color: kNavy,
                                            fontWeight: FontWeight.w800,
                                            fontSize: 10.5,
                                          ),
                                        ),
                                        Text(
                                          '- ${item['desc']}',
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            color: kTextMuted,
                                            fontSize: 9.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}