// ignore_for_file: implementation_imports

const String kWidgetPreviewDtdUri = 'ws://127.0.0.1:61324/GQHTzBhRuNY=';
const String kWidgetPreviewService =
    'widget-preview-a03f0480-3ce2-4959-9c16-4746a349cd2b';
const String kWidgetPreviewScaffoldStream =
    'WidgetPreviewScaffold-a03f0480-3ce2-4959-9c16-4746a349cd2b';
const String kProjectRootPath = r'E:\Map for hachaton\tour_toru';
