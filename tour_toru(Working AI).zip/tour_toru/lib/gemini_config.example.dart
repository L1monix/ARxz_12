// Copy this file to gemini_config.dart and paste your API key between the quotes.
const geminiApiKey = '';
