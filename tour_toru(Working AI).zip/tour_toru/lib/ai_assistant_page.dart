import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_markdown_plus/flutter_markdown_plus.dart';
import 'package:http/http.dart' as http;

import 'gemini_config.dart';
import 'home_page.dart';

class AiAssistantPage extends StatefulWidget {
  const AiAssistantPage({super.key});

  @override
  State<AiAssistantPage> createState() => _AiAssistantPageState();
}

class _AiAssistantPageState extends State<AiAssistantPage> {
  final TextEditingController _inputCtrl = TextEditingController();
  final ScrollController _messagesScrollCtrl = ScrollController();
  final _GeminiAssistant _assistant = _GeminiAssistant();
  late final _ChatConversation _initialConversation = _createConversation();
  late final List<_ChatConversation> _conversations = [_initialConversation];
  late _ChatConversation _activeConversation = _initialConversation;

  bool _historyOpen = false;
  int _nextConversationId = 1;
  String selectedTopic = 'Old Town Gothic';

  final Map<String, String> topicGuides = {
    'Old Town Gothic':
        'Toruń’s Medieval Town is a UNESCO World Heritage site! Start at the Old Town Hall (Ratusz), visit the Cathedral of SS. John the Baptist and John the Evangelist, and see the Leaning Tower (Krzywa Wieża).',
    'Copernicus Trail':
        'Nicolaus Copernicus was born in Toruń in 1473! Visit the House of Nicolaus Copernicus Museum on Kopernika 15/17, take a photo at his monument on the Market Square, and watch a show at the Planetarium.',
    'Gingerbread & Food':
        'Toruń is the capital of Polish gingerbread (Pierniki). Visit the Living Museum of Gingerbread to bake your own Katarzynki, and try pierogi in the Old Town.',
    'Vistula & Ruins':
        'Walk along Bulwar Filadelfijski by the Vistula River, explore the 13th-century Teutonic Castle ruins, and cross to the Kępa Bazarowa viewpoint at sunset for the best skyline photo!',
  };

  _ChatConversation _createConversation() {
    return _ChatConversation(
      id: _nextConversationId++,
      title: 'New chat',
      messages: [
        _ChatMessage(
          role: 'model',
          text:
              'Welcome to Toruń! Ask me about local attractions, Copernicus, gingerbread, quests, or ideas for exploring the city.',
        ),
      ],
    );
  }

  void _startNewChat() {
    setState(() {
      final conversation = _createConversation();
      _conversations.insert(0, conversation);
      _activeConversation = conversation;
      _historyOpen = false;
    });
    _scrollToLatest();
  }

  void _openConversation(_ChatConversation conversation) {
    setState(() {
      _activeConversation = conversation;
      _historyOpen = false;
    });
    _scrollToLatest();
  }

  Future<void> _sendMessage([String? preset]) async {
    final text = (preset ?? _inputCtrl.text).trim();
    if (text.isEmpty || _activeConversation.isSending) return;

    final conversation = _activeConversation;
    setState(() {
      conversation.messages.add(_ChatMessage(role: 'user', text: text));
      if (conversation.title == 'New chat') {
        conversation.title =
            text.length > 32 ? '${text.substring(0, 32)}…' : text;
      }
      _inputCtrl.clear();
      conversation.isSending = true;
    });
    _scrollToLatest();

    try {
      final answer = await _assistant.generateReply(conversation.messages);
      if (!mounted) return;
      setState(() {
        conversation.messages.add(_ChatMessage(role: 'model', text: answer));
        conversation.isSending = false;
      });
      if (identical(conversation, _activeConversation)) _scrollToLatest();
    } on _GeminiAssistantException catch (error) {
      if (!mounted) return;
      setState(() {
        conversation.messages.add(
          _ChatMessage(role: 'model', text: error.message, isError: true),
        );
        conversation.isSending = false;
      });
      if (identical(conversation, _activeConversation)) _scrollToLatest();
    }
  }

  void _scrollToLatest() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_messagesScrollCtrl.hasClients) {
        _messagesScrollCtrl.animateTo(
          _messagesScrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _messagesScrollCtrl.dispose();
    _assistant.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final drawerWidth =
        (MediaQuery.sizeOf(context).width * 0.78).clamp(0.0, 260.0).toDouble();

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: kCardWhite,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kNavy.withValues(alpha: 0.25), width: 1.5),
        ),
        child: Stack(
          children: [
            _buildChat(),
            if (_historyOpen)
              Positioned.fill(
                child: GestureDetector(
                  onTap: () => setState(() => _historyOpen = false),
                  child: Container(color: Colors.black.withValues(alpha: 0.25)),
                ),
              ),
            AnimatedPositioned(
              duration: const Duration(milliseconds: 240),
              curve: Curves.easeOutCubic,
              left: _historyOpen ? 0 : -drawerWidth,
              top: 0,
              bottom: 0,
              width: drawerWidth,
              child: _buildHistoryDrawer(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChat() {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            decoration: BoxDecoration(
              color: kSoftBlue,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                IconButton(
                  tooltip: 'Chat history',
                  visualDensity: VisualDensity.compact,
                  onPressed: () => setState(() => _historyOpen = true),
                  icon: const Icon(Icons.menu_rounded, color: kNavy, size: 20),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Toruń AI Tourist Assistant',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: kNavy,
                          fontWeight: FontWeight.w800,
                          fontSize: 11.5,
                        ),
                      ),
                      Text(
                        _activeConversation.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: kNavy.withValues(alpha: 0.68),
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'New chat',
                  visualDensity: VisualDensity.compact,
                  onPressed: _startNewChat,
                  icon: const Icon(Icons.add_comment_outlined,
                      color: kNavy, size: 19),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.builder(
              controller: _messagesScrollCtrl,
              padding: const EdgeInsets.symmetric(vertical: 2),
              itemCount: _activeConversation.messages.length +
                  (_activeConversation.isSending ? 1 : 0),
              itemBuilder: (context, index) {
                if (_activeConversation.isSending &&
                    index == _activeConversation.messages.length) {
                  return const Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding:
                          EdgeInsets.symmetric(vertical: 8, horizontal: 10),
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: kNavy),
                      ),
                    ),
                  );
                }
                final message = _activeConversation.messages[index];
                final isUser = message.role == 'user';
                return Align(
                  alignment:
                      isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(10),
                    constraints: const BoxConstraints(maxWidth: 260),
                    decoration: BoxDecoration(
                      color: isUser ? kNavy : kSoftBlue,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: isUser || message.isError
                        ? Text(
                            message.text,
                            style: TextStyle(
                              color: message.isError
                                  ? Colors.red.shade900
                                  : Colors.white,
                              fontSize: 12,
                              height: 1.4,
                            ),
                          )
                        : MarkdownBody(
                            data: message.text,
                            selectable: true,
                            styleSheet: MarkdownStyleSheet.fromTheme(
                              Theme.of(context),
                            ).copyWith(
                              p: const TextStyle(
                                color: kNavy,
                                fontSize: 12,
                                height: 1.4,
                              ),
                              h1: const TextStyle(
                                color: kNavy,
                                fontSize: 19,
                                fontWeight: FontWeight.w800,
                              ),
                              h2: const TextStyle(
                                color: kNavy,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                              h3: const TextStyle(
                                color: kNavy,
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                              ),
                              strong: const TextStyle(
                                color: kNavy,
                                fontWeight: FontWeight.w800,
                              ),
                              code: const TextStyle(
                                color: kNavy,
                                fontSize: 11,
                                fontFamily: 'monospace',
                                backgroundColor: kSoftBlue,
                              ),
                              blockSpacing: 8,
                              pPadding: EdgeInsets.zero,
                              h1Padding:
                                  const EdgeInsets.only(top: 6, bottom: 3),
                              h2Padding:
                                  const EdgeInsets.only(top: 5, bottom: 2),
                              h3Padding:
                                  const EdgeInsets.only(top: 4, bottom: 2),
                            ),
                          ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 42,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: kSoftBlue,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: kNavy.withValues(alpha: 0.35)),
                  ),
                  alignment: Alignment.center,
                  child: TextField(
                    controller: _inputCtrl,
                    textInputAction: TextInputAction.send,
                    decoration: const InputDecoration(
                      hintText: 'Ask about Toruń sights...',
                      border: InputBorder.none,
                      isDense: true,
                    ),
                    style: const TextStyle(fontSize: 12, color: kNavy),
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              InkWell(
                onTap: _activeConversation.isSending ? null : _sendMessage,
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  width: 40,
                  height: 42,
                  decoration: BoxDecoration(
                    color: _activeConversation.isSending
                        ? kNavy.withValues(alpha: 0.5)
                        : kNavy,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.send_rounded,
                      color: Colors.white, size: 18),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryDrawer() {
    return Material(
      color: kSoftBlue,
      child: SafeArea(
        top: false,
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 14, 8, 8),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Your chats',
                      style: TextStyle(
                        color: kNavy,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Close history',
                    visualDensity: VisualDensity.compact,
                    onPressed: () => setState(() => _historyOpen = false),
                    icon: const Icon(Icons.close, color: kNavy, size: 19),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _startNewChat,
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('New chat'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: kNavy,
                    side: BorderSide(color: kNavy.withValues(alpha: 0.35)),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(14, 16, 10, 7),
              child: Text(
                'RECENT',
                style: TextStyle(
                  color: kNavy,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.8,
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                children: [
                  ..._conversations.map((conversation) {
                    final selected =
                        identical(conversation, _activeConversation);
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: ListTile(
                        dense: true,
                        visualDensity: VisualDensity.compact,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(9)),
                        selected: selected,
                        selectedTileColor: kCardWhite,
                        leading: const Icon(Icons.chat_bubble_outline,
                            size: 17, color: kNavy),
                        title: Text(
                          conversation.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: kNavy,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        onTap: () => _openConversation(conversation),
                      ),
                    );
                  }),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(6, 16, 6, 7),
                    child: Text(
                      'EXPLORE TORUŃ',
                      style: TextStyle(
                        color: kNavy,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                  ...topicGuides.keys.map(
                    (topic) => ListTile(
                      dense: true,
                      visualDensity: VisualDensity.compact,
                      leading: const Icon(Icons.explore_outlined,
                          size: 17, color: kNavy),
                      title: Text(
                        topic,
                        style: const TextStyle(color: kNavy, fontSize: 11),
                      ),
                      onTap: () {
                        setState(() {
                          selectedTopic = topic;
                          _historyOpen = false;
                        });
                        _sendMessage('Tell me about $topic in Toruń');
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChatConversation {
  _ChatConversation({
    required this.id,
    required this.title,
    required this.messages,
  });

  final int id;
  String title;
  final List<_ChatMessage> messages;
  bool isSending = false;
}

class _ChatMessage {
  const _ChatMessage({
    required this.role,
    required this.text,
    this.isError = false,
  });

  final String role;
  final String text;
  final bool isError;
}

class _GeminiAssistant {
  static const _apiKey = geminiApiKey;
  static const _systemInstruction =
      'Jesteś pomocnym przewodnikiem dla turystów i osób, które chcą odkrywać '
      'ciekawe miejsca w Toruniu (Polska, województwo kujawsko-pomorskie). '
      'Pomagasz użytkownikom aplikacji poświęconej Toruniowi. Aplikacja oferuje '
      'nagrody za wykonywanie miejskich questów, personalizację postaci w profilu, '
      'sklep z elementami wyglądu postaci oraz forum społecznościowe przypominające '
      'Threads. Odpowiadaj praktycznie i życzliwie, przede wszystkim na pytania '
      'związane z Toruniem. Pisz po polsku, chyba że użytkownik zwróci się w innym '
      'języku. Nie wymyślaj aktualnych godzin otwarcia, cen ani wydarzeń; zaznacz, '
      'gdy takie informacje trzeba sprawdzić w aktualnym źródle.';

  final http.Client _client = http.Client();

  Future<String> generateReply(List<_ChatMessage> messages) async {
    if (_apiKey.isEmpty) {
      throw const _GeminiAssistantException(
        'AI is not configured. Add your Google AI Studio API key to lib/gemini_config.dart.',
      );
    }

    final contents = messages
        .where((message) => !message.isError)
        .map(
          (message) => {
            'role': message.role,
            'parts': [
              {'text': message.text},
            ],
          },
        )
        .toList();

    try {
      final response = await _client
          .post(
            Uri.parse(
              'https://generativelanguage.googleapis.com/v1beta/models/'
              'gemini-3.8-flash:generateContent',
            ),
            headers: {
              'Content-Type': 'application/json',
              'x-goog-api-key': _apiKey,
            },
            body: jsonEncode({
              'system_instruction': {
                'parts': [
                  {'text': _systemInstruction},
                ],
              },
              'contents': contents,
              'generationConfig': {'temperature': 0.7, 'maxOutputTokens': 1200},
            }),
          )
          .timeout(const Duration(seconds: 35));

      final body = jsonDecode(response.body);
      if (body is! Map<String, dynamic>) {
        throw const _GeminiAssistantException(
            'Google AI returned an invalid response.');
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        final error = body['error'];
        final message =
            error is Map<String, dynamic> && error['message'] is String
                ? error['message'] as String
                : 'Request failed with status ${response.statusCode}.';
        throw _GeminiAssistantException('Google AI error: $message');
      }

      final candidates = body['candidates'];
      if (candidates is List && candidates.isNotEmpty) {
        final candidate = candidates.first;
        if (candidate is Map<String, dynamic>) {
          final content = candidate['content'];
          if (content is Map<String, dynamic> && content['parts'] is List) {
            final text = (content['parts'] as List)
                .whereType<Map<String, dynamic>>()
                .map((part) => part['text'])
                .whereType<String>()
                .join()
                .trim();
            if (text.isNotEmpty) return text;
          }
        }
      }
      throw const _GeminiAssistantException(
        'Google AI did not return a text response. Please try asking another way.',
      );
    } on _GeminiAssistantException {
      rethrow;
    } on http.ClientException {
      throw const _GeminiAssistantException(
        'Could not connect to Google AI. Check your internet connection and try again.',
      );
    } on TimeoutException {
      throw const _GeminiAssistantException(
        'Google AI took too long to respond. Please try again.',
      );
    } on FormatException {
      throw const _GeminiAssistantException(
        'Google AI returned unreadable data. Please try again.',
      );
    }
  }

  void dispose() => _client.close();
}

class _GeminiAssistantException implements Exception {
  const _GeminiAssistantException(this.message);

  final String message;
}
