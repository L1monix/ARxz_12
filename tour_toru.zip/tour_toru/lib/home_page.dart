import 'package:flutter/material.dart';

// App-wide colors matching main.png
const kBgBlue = Color(0xFFDCE8FC);
const kCardWhite = Color(0xFFF8FBFF);
const kSoftBlue = Color(0xFFE5EFFD);
const kNavy = Color(0xFF25476A);
const kNavyLight = Color(0xFF395B80);
const kTextMuted = Color(0xFF6B85A3);

class QuestItem {
  final String title;
  final IconData icon;
  String badge;
  bool completed;
  final int reward;

  QuestItem({
    required this.title,
    required this.icon,
    required this.badge,
    this.completed = false,
    required this.reward,
  });
}

class StoreItem {
  final String id;
  final String name;
  final String slot;
  final int price;
  final IconData icon;
  final Color color;
  bool owned;
  bool equipped;

  StoreItem({
    required this.id,
    required this.name,
    required this.slot,
    required this.price,
    required this.icon,
    required this.color,
    this.owned = false,
    this.equipped = false,
  });
}

class AvatarWidget extends StatelessWidget {
  final List<StoreItem> storeItems;
  final double size;

  const AvatarWidget({
    super.key,
    required this.storeItems,
    this.size = 86,
  });

  @override
  Widget build(BuildContext context) {
    final equipped = storeItems.where((e) => e.equipped).toList();
    final hasShades = equipped.any((e) => e.id == 'shades');
    final headItem = equipped.where((e) => e.slot == 'head').firstOrNull;
    final neckItem = equipped.where((e) => e.slot == 'neck').firstOrNull;
    final badgeItem = equipped.where((e) => e.slot == 'badge').firstOrNull;

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: kSoftBlue,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: size - 10,
            height: size - 10,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [Color(0xFFFFE57F), Color(0xFFFF8A65)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
          ),
          Positioned(
            bottom: 14,
            child: Container(
              width: 34,
              height: 12,
              decoration: BoxDecoration(
                color: Colors.brown.shade700,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          Positioned(
            bottom: 18,
            child: Column(
              children: [
                Container(
                  width: 26,
                  height: 24,
                  decoration: const BoxDecoration(
                    color: Color(0xFF66BB6A),
                    shape: BoxShape.circle,
                  ),
                ),
                Container(
                  width: 22,
                  height: 16,
                  decoration: BoxDecoration(
                    color: const Color(0xFF4CAF50),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ],
            ),
          ),
          if (hasShades)
            Positioned(
              top: 28,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 11,
                    height: 8,
                    decoration: BoxDecoration(
                      color: Colors.black87,
                      border: Border.all(color: Colors.orangeAccent, width: 1.5),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  Container(width: 3, height: 2, color: Colors.orangeAccent),
                  Container(
                    width: 11,
                    height: 8,
                    decoration: BoxDecoration(
                      color: Colors.black87,
                      border: Border.all(color: Colors.orangeAccent, width: 1.5),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ],
              ),
            ),
          if (headItem != null)
            Positioned(
              top: 8,
              child: Icon(headItem.icon, color: headItem.color, size: 22),
            ),
          if (neckItem != null)
            Positioned(
              bottom: 24,
              child: Icon(neckItem.icon, color: neckItem.color, size: 18),
            ),
          if (badgeItem != null)
            Positioned(
              right: 8,
              bottom: 8,
              child: CircleAvatar(
                radius: 10,
                backgroundColor: Colors.white,
                child: Icon(badgeItem.icon, color: badgeItem.color, size: 14),
              ),
            ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final List<QuestItem> quests;
  final List<StoreItem> storeItems;
  final int coins;
  final int completedQuestsBase;
  final bool showQuestMapOnHome;
  final ValueChanged<bool> onToggleQuestMap;
  final ValueChanged<QuestItem> onCompleteQuest;
  final VoidCallback onOpenFullMap;

  const HomePage({
    super.key,
    required this.quests,
    required this.storeItems,
    required this.coins,
    required this.completedQuestsBase,
    required this.showQuestMapOnHome,
    required this.onToggleQuestMap,
    required this.onCompleteQuest,
    required this.onOpenFullMap,
  });

  @override
  Widget build(BuildContext context) {
    final inProgressCount = quests.where((q) => !q.completed).length;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
      child: Column(
        children: [
          IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(child: _buildQuestsCard()),
                const SizedBox(width: 10),
                Expanded(child: _buildUserCard(context)),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildTogglePill('Stats', !showQuestMapOnHome, () => onToggleQuestMap(false)),
              const SizedBox(width: 10),
              _buildTogglePill('Quest Map', showQuestMapOnHome, () => onToggleQuestMap(true)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildStatCard('Today', '4,280 steps', '2.8 km walked'),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildStatCard(
                  'Quests',
                  '$completedQuestsBase completed',
                  '$inProgressCount in progress',
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildStatCard('Rewards', '$coins coins', '1 new badge'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            height: 190,
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: kCardWhite,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFFEAF2FF),
                borderRadius: BorderRadius.circular(14),
              ),
              child: showQuestMapOnHome
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.map_outlined, size: 42, color: kNavy),
                          const SizedBox(height: 6),
                          const Text(
                            'Old Town Toruń Quest Loop',
                            style: TextStyle(color: kNavy, fontWeight: FontWeight.bold),
                          ),
                          TextButton(
                            onPressed: onOpenFullMap,
                            child: const Text('Open Full Interactive Map →'),
                          ),
                        ],
                      ),
                    )
                  : CustomPaint(
                      painter: _QuestGraphPainter(),
                      child: const SizedBox.expand(),
                    ),
            ),
          ),
          const SizedBox(height: 8),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Next stop: City Hall',
                  style: TextStyle(
                    color: kNavy,
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                  ),
                ),
                Text(
                  '0.8 km • 12 min walk',
                  style: TextStyle(
                    color: kTextMuted,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuestsCard() {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: kCardWhite,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: kSoftBlue,
              borderRadius: BorderRadius.circular(12),
            ),
            alignment: Alignment.center,
            child: const Text(
              'Quests',
              style: TextStyle(
                color: kNavy,
                fontWeight: FontWeight.w800,
                fontSize: 15,
              ),
            ),
          ),
          const SizedBox(height: 8),
          ...quests.map((q) => Padding(
                padding: const EdgeInsets.only(bottom: 7),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => onCompleteQuest(q),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
                    decoration: BoxDecoration(
                      color: q.completed ? const Color(0xFFD5E8D4) : kSoftBlue,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        Icon(q.icon, size: 15, color: kNavy),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            q.title,
                            style: const TextStyle(
                              color: kNavy,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFFD5E4FA),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            q.badge,
                            style: const TextStyle(
                              color: kNavy,
                              fontSize: 9.5,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              )),
        ],
      ),
    );
  }

  Widget _buildUserCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: kCardWhite,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 7),
                  decoration: BoxDecoration(
                    color: kSoftBlue,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  alignment: Alignment.center,
                  child: const Text(
                    'User',
                    style: TextStyle(
                      color: kNavy,
                      fontWeight: FontWeight.w800,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              InkWell(
                borderRadius: BorderRadius.circular(10),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Settings: Toruń Guide v1.0 (English)')),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
                  decoration: BoxDecoration(
                    color: kSoftBlue,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Text(
                    'Settings',
                    style: TextStyle(
                      color: kNavy,
                      fontWeight: FontWeight.w700,
                      fontSize: 10,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 6,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Traveler Guide',
                      style: TextStyle(
                        color: kTextMuted,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    AvatarWidget(storeItems: storeItems, size: 86),
                    const SizedBox(height: 4),
                    const Text(
                      '4 badges earned',
                      style: TextStyle(
                        color: kTextMuted,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                flex: 4,
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                  decoration: BoxDecoration(
                    color: kSoftBlue,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        'Badges:',
                        style: TextStyle(
                          color: kTextMuted,
                          fontSize: 9.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      ...List.generate(
                        4,
                        (i) => Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Container(
                            width: 22,
                            height: 22,
                            decoration: BoxDecoration(
                              color: kCardWhite,
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(color: const Color(0xFFB8C9E6)),
                            ),
                            child: const Icon(Icons.stars_rounded, size: 13, color: kNavy),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: kSoftBlue,
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: const Text(
                'A little further.\nA new discovery.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: kNavy,
                  fontWeight: FontWeight.w600,
                  fontSize: 11.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTogglePill(String text, bool active, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 110,
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: active ? kNavy : kSoftBlue,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kNavy.withValues(alpha: 0.25)),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: TextStyle(
            color: active ? Colors.white : kNavy,
            fontWeight: FontWeight.w700,
            fontSize: 12,
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard(String label, String mainValue, String subValue) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: kCardWhite,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: kTextMuted,
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            mainValue,
            style: const TextStyle(
              color: kNavy,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            subValue,
            style: const TextStyle(
              color: kTextMuted,
              fontSize: 9.5,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

class _QuestGraphPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = const Color(0xFFD6E4FA)
      ..strokeWidth = 1;

    for (int i = 1; i < 4; i++) {
      final y = size.height * (i / 4);
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
    for (int i = 1; i < 5; i++) {
      final x = size.width * (i / 5);
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }

    final pts = [
      Offset(size.width * 0.18, size.height * 0.25),
      Offset(size.width * 0.35, size.height * 0.25),
      Offset(size.width * 0.35, size.height * 0.52),
      Offset(size.width * 0.52, size.height * 0.52),
      Offset(size.width * 0.52, size.height * 0.78),
    ];

    final linePaint = Paint()
      ..color = kNavy.withValues(alpha: 0.45)
      ..strokeWidth = 1.8
      ..style = PaintingStyle.stroke;

    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (final p in pts.skip(1)) {
      path.lineTo(p.dx, p.dy);
    }
    canvas.drawPath(path, linePaint);

    final dotPaint = Paint()..color = kNavy;
    for (final p in pts) {
      canvas.drawCircle(p, 3.5, dotPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}